import React from 'react';
import { TouchableOpacity, Image, Text, StyleSheet } from 'react-native';

export default function CategoryButton({ category, selected, onPress }) {
  return (
    <TouchableOpacity
      style={[styles.container, selected && styles.selected]}
      onPress={onPress}
    >
      <Image source={category.image} style={styles.image} />
      <Text style={styles.text}>{category.name}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginRight: 15,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 8,
  },
  selected: { borderColor: '#D62828' },
  image: { width: 50, height: 50, resizeMode: 'contain' },
  text: { fontSize: 13, marginTop: 5 },
});
