import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function BurgerCard({ burger, onPress }) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Image source={burger.image} style={styles.image} />
      <Text style={styles.name}>{burger.name}</Text>
      <Text style={styles.price}>Rs. {burger.price}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 10,
    alignItems: 'center',
    flex: 0.48,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#eee',
    elevation: 3,
  },
  image: { width: 100, height: 100, resizeMode: 'contain' },
  name: { fontSize: 14, fontWeight: '600', marginTop: 5, textAlign: 'center' },
  price: { fontSize: 14, color: '#D62828', fontWeight: 'bold', marginTop: 5 },
});
