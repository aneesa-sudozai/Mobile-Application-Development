import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const orders = [
  { id: '1', name: 'Classic Beef Burger', price: 750, quantity: 2 },
  { id: '2', name: 'Zinger Chicken Burger', price: 650, quantity: 1 },
];

export default function OrderScreen({ navigation }) {
  const total = orders.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="arrow-back-outline" size={24} color="#000" onPress={() => navigation.goBack()} />
        <Text style={styles.title}>My Orders</Text>
      </View>

      <FlatList
        data={orders}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.orderItem}>
            <Text style={styles.orderName}>{item.name}</Text>
            <Text style={styles.orderQty}>x{item.quantity}</Text>
            <Text style={styles.orderPrice}>Rs.{item.price * item.quantity}</Text>
          </View>
        )}
      />

      <View style={styles.totalContainer}>
        <Text style={styles.totalLabel}>Total</Text>
        <Text style={styles.totalAmount}>Rs.{total}</Text>
      </View>

      <TouchableOpacity style={styles.checkoutBtn}>
        <Text style={styles.checkoutText}>Proceed to Checkout</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 16 },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 20, fontWeight: 'bold', marginLeft: 10 },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  orderName: { fontSize: 16, fontWeight: '600' },
  orderQty: { fontSize: 14, color: '#555' },
  orderPrice: { fontSize: 16, color: '#D62828', fontWeight: 'bold' },
  totalContainer: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  totalLabel: { fontSize: 18, fontWeight: 'bold' },
  totalAmount: { fontSize: 18, fontWeight: 'bold', color: '#D62828' },
  checkoutBtn: {
    backgroundColor: '#D62828',
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 25,
  },
  checkoutText: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
