import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function BurgerDetailScreen({ route, navigation }) {
  const { burger } = route.params || {
    burger: {
      name: 'Classic Beef Burger',
      price: 900,
      image: require('../assets/burger.png'),
    },
  };

  const [quantity, setQuantity] = useState(2);
  const [selectedCombo, setSelectedCombo] = useState(null);

  const handleQuantityChange = (type) => {
    setQuantity((prev) => (type === 'inc' ? prev + 1 : prev > 1 ? prev - 1 : 1));
  };

  const totalPrice =
    burger.price +
    (selectedCombo === 'Drink' ? 150 : 0) +
    (selectedCombo === 'Fries' ? 100 : 0);

  return (
    <View style={styles.container}>
      {/* Top bar */}
      <View style={styles.topBar}>
        <Text style={styles.time}>10:00 pm</Text>
        <View style={styles.topIcons}>
          <Ionicons
            name="arrow-back-outline"
            size={24}
            color="#000"
            onPress={() => navigation.goBack()}
          />
          <Ionicons name="heart-outline" size={24} color="#D62828" />
        </View>
      </View>

      {/* Burger Image */}
      <Image source={burger.image} style={styles.image} />

      {/* Burger Info */}
      <Text style={styles.title}>{burger.name}</Text>
      <View style={styles.ratingContainer}>
        {[1, 2, 3, 4, 5].map((i) => (
          <Ionicons
            key={i}
            name={i <= 4 ? 'star' : 'star-outline'}
            size={18}
            color="#FFD60A"
          />
        ))}
        <Text style={styles.reviewText}>(128 reviews)</Text>
      </View>

      <Text style={styles.description}>
        "A juicy, flame-grilled beef patty layered with fresh lettuce, tomatoes,
        creamy mayo, and melted cheddar cheese — all inside a toasted sesame bun.
        Classic, bold, and full of flavor."
      </Text>

      {/* Combo Section */}
      <Text style={styles.sectionTitle}>Add Combo?</Text>
      <View style={styles.comboContainer}>
        <TouchableOpacity
          style={[
            styles.comboBox,
            selectedCombo === 'Drink' && styles.selectedCombo,
          ]}
          onPress={() =>
            setSelectedCombo(selectedCombo === 'Drink' ? null : 'Drink')
          }
        >
          <Image
            source={require('../assets/burger.png')}
            style={styles.comboImage}
          />
          <Text style={styles.comboText}>Cold Drink{'\n'}Rs. 150</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.comboBox,
            selectedCombo === 'Fries' && styles.selectedCombo,
          ]}
          onPress={() =>
            setSelectedCombo(selectedCombo === 'Fries' ? null : 'Fries')
          }
        >
          <Image
            source={require('../assets/burger.png')}
            style={styles.comboImage}
          />
          <Text style={styles.comboText}>Fries{'\n'}Rs. 100</Text>
        </TouchableOpacity>
      </View>

      {/* Quantity Section */}
      <Text style={styles.sectionTitle}>Quantity</Text>
      <View style={styles.quantityContainer}>
        <TouchableOpacity
          style={styles.qtyButton}
          onPress={() => handleQuantityChange('dec')}
        >
          <Text style={styles.qtySymbol}>-</Text>
        </TouchableOpacity>
        <Text style={styles.qtyValue}>{quantity}</Text>
        <TouchableOpacity
          style={styles.qtyButton}
          onPress={() => handleQuantityChange('inc')}
        >
          <Text style={styles.qtySymbol}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Total Price */}
      <Text style={styles.totalLabel}>Total Price</Text>
      <Text style={styles.totalPrice}>Rs.{totalPrice * quantity}</Text>

      {/* Add to Cart Button */}
      <TouchableOpacity style={styles.addButton}>
        <Text style={styles.addText}>Add to Cart</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 16,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
    alignItems: 'center',
  },
  time: { fontWeight: 'bold', fontSize: 14 },
  topIcons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  image: {
    width: '100%',
    height: 220,
    resizeMode: 'contain',
    marginTop: 10,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 10,
  },
  ratingContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 6,
  },
  reviewText: {
    marginLeft: 6,
    color: '#777',
    fontSize: 13,
  },
  description: {
    textAlign: 'center',
    color: '#555',
    fontSize: 14,
    marginBottom: 15,
    lineHeight: 20,
  },
  sectionTitle: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 8,
  },
  comboContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  comboBox: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    width: 130,
  },
  selectedCombo: {
    borderColor: '#D62828',
  },
  comboImage: { width: 40, height: 40, resizeMode: 'contain' },
  comboText: {
    fontSize: 13,
    textAlign: 'center',
    marginTop: 5,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 15,
  },
  qtyButton: {
    backgroundColor: '#D62828',
    borderRadius: 5,
    padding: 8,
    width: 40,
    alignItems: 'center',
  },
  qtySymbol: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  qtyValue: {
    fontSize: 18,
    fontWeight: 'bold',
    marginHorizontal: 15,
  },
  totalLabel: {
    textAlign: 'center',
    fontSize: 16,
    marginTop: 5,
  },
  totalPrice: {
    textAlign: 'center',
    fontSize: 22,
    fontWeight: 'bold',
    color: '#D62828',
    marginBottom: 20,
  },
  addButton: {
    backgroundColor: '#D62828',
    paddingVertical: 14,
    borderRadius: 10,
    marginHorizontal: 40,
    marginBottom: 20,
  },
  addText: {
    textAlign: 'center',
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
