import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

const categories = [
  { id: '1', name: 'All', image: require('../assets/burger.png') },
  { id: '2', name: 'Beef', image: require('../assets/burger.png') },
  { id: '3', name: 'Chicken', image: require('../assets/burger.png') },
  { id: '4', name: 'Mutton', image: require('../assets/burger.png') },
];

const burgers = [
  { id: '1', name: 'Classic Beef Burger', price: 750, image: require('../assets/burger.png') },
  { id: '2', name: 'Zinger Chicken Burger', price: 650, image: require('../assets/burger.png') },
  { id: '3', name: 'Cheese Burger', price: 700, image: require('../assets/burger.png') },
  { id: '4', name: 'Double Mutton Burger', price: 950, image: require('../assets/burger.png') },
];

export default function HomeScreen({ navigation }) {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const renderCategory = ({ item }) => (
    <TouchableOpacity
      style={[
        styles.categoryItem,
        selectedCategory === item.name && styles.categorySelected,
      ]}
      onPress={() => setSelectedCategory(item.name)}
    >
      <Image source={item.image} style={styles.categoryImage} />
      <Text style={styles.categoryText}>{item.name}</Text>
    </TouchableOpacity>
  );

  const renderBurger = ({ item }) => (
    <TouchableOpacity
      style={styles.burgerCard}
      onPress={() => navigation.navigate('BurgerDetail', { burger: item })}
    >
      <Image source={item.image} style={styles.burgerImage} />
      <Text style={styles.burgerName}>{item.name}</Text>
      <Text style={styles.burgerPrice}>Rs. {item.price}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <Text style={styles.time}>10:00 pm</Text>
        <View style={styles.rightIcons}>
          <Ionicons name="menu-outline" size={22} color="#000" style={{ marginRight: 10 }} />
          <Ionicons name="person-circle-outline" size={28} color="#000" />
        </View>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <Ionicons name="search-outline" size={20} color="#777" />
        <TextInput placeholder="Search for burgers..." style={styles.searchInput} />
        <View style={styles.filterBtn}>
          <Ionicons name="options-outline" size={20} color="#fff" />
        </View>
      </View>

      {/* Categories */}
      <Text style={styles.sectionTitle}>Categories</Text>
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={categories}
        keyExtractor={(item) => item.id}
        renderItem={renderCategory}
        contentContainerStyle={styles.categoriesList}
      />

      {/* Banner */}
      <View style={styles.banner}>
        <Text style={styles.bannerText}>"Not Just a Burger — an Experience."</Text>
        <Image source={require('../assets/burger.png')} style={styles.bannerImage} />
      </View>

      {/* Menu Section */}
      <Text style={styles.sectionTitle}>Menu</Text>
      <FlatList
        data={burgers}
        numColumns={2}
        keyExtractor={(item) => item.id}
        renderItem={renderBurger}
        columnWrapperStyle={{ justifyContent: 'space-between' }}
        contentContainerStyle={{ paddingBottom: 100 }}
      />

      {/* Bottom Nav */}
      <View style={styles.bottomNav}>
        <Ionicons name="home" size={24} color="#000" />
        <TouchableOpacity style={styles.addButton}>
          <Ionicons name="add" size={26} color="#fff" />
        </TouchableOpacity>
        <Ionicons name="notifications-outline" size={24} color="#000" />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', paddingHorizontal: 16 },
  time: { fontWeight: 'bold', fontSize: 14 },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
  },
  rightIcons: { flexDirection: 'row', alignItems: 'center' },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    marginVertical: 15,
    paddingHorizontal: 10,
    height: 45,
  },
  searchInput: { flex: 1, marginLeft: 8, color: '#333' },
  filterBtn: {
    backgroundColor: '#D62828',
    padding: 8,
    borderRadius: 8,
  },
  sectionTitle: { fontWeight: 'bold', fontSize: 16, marginVertical: 10 },
  categoriesList: { paddingVertical: 5 },
  categoryItem: {
    alignItems: 'center',
    marginRight: 15,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    padding: 8,
  },
  categorySelected: { borderColor: '#D62828' },
  categoryImage: { width: 50, height: 50, resizeMode: 'contain' },
  categoryText: { fontSize: 13, marginTop: 5 },
  banner: {
    backgroundColor: '#D62828',
    borderRadius: 15,
    padding: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 15,
  },
  bannerText: {
    color: '#FFD60A',
    fontSize: 16,
    fontStyle: 'italic',
    width: '60%',
  },
  bannerImage: { width: 110, height: 110, resizeMode: 'contain' },
  burgerCard: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 10,
    alignItems: 'center',
    marginBottom: 15,
    flex: 0.48,
    borderWidth: 1,
    borderColor: '#eee',
    elevation: 3,
  },
  burgerImage: { width: 100, height: 100, resizeMode: 'contain' },
  burgerName: { fontSize: 14, fontWeight: '600', marginTop: 5, textAlign: 'center' },
  burgerPrice: { fontSize: 14, color: '#D62828', fontWeight: 'bold', marginTop: 5 },
  bottomNav: {
    position: 'absolute',
    bottom: 10,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderColor: '#eee',
    paddingVertical: 10,
  },
  addButton: {
    backgroundColor: '#D62828',
    width: 50,
    height: 50,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5,
  },
});
