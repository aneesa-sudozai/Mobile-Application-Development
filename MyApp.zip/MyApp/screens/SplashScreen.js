import React, { useEffect } from 'react';
import { View, Image, Text, StyleSheet, StatusBar } from 'react-native';

export default function SplashScreen({ navigation }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('Home');
    }, 2000);
    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#D62828" barStyle="light-content" />

      {/* Mock Time at top left */}
      <Text style={styles.time}>10:00 pm</Text>

      {/* Decorative Circles */}
      <View style={[styles.circle, styles.circleTopRight]} />
      <View style={[styles.circle, styles.circleBottomLeft]} />

      {/* Logo Content */}
      <View style={styles.content}>
        <Image
          source={require('../assets/burger.png')} // same image you used
          style={styles.logo}
          resizeMode="contain"
        />
        <Text style={styles.brand}>JuicyBite</Text>
        <Text style={styles.subtitle}>Welcome to JuicyBite</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#D62828',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  time: {
    position: 'absolute',
    top: 15,
    left: 15,
    color: '#000',
    fontWeight: 'bold',
    fontSize: 14,
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 200,
    height: 200,
  },
  brand: {
    fontSize: 36,
    color: '#FFD60A',
    fontFamily: 'cursive',
    marginTop: 10,
  },
  subtitle: {
    fontSize: 18,
    color: '#fff',
    fontWeight: '600',
    marginTop: 8,
  },
  circle: {
    position: 'absolute',
    borderWidth: 15,
    borderColor: 'rgba(255, 87, 34, 0.3)',
    borderRadius: 100,
    width: 120,
    height: 120,
  },
  circleTopRight: {
    top: 100,
    right: -40,
  },
  circleBottomLeft: {
    bottom: 100,
    left: -40,
  },
});
