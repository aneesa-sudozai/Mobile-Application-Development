import { StyleSheet, Dimensions } from "react-native";

const { width } = Dimensions.get("window");
const cardWidth = (width - 36) / 2;

export const GlobalStyles = StyleSheet.create({
  // Common container styles
  container: { 
    flex: 1, 
    backgroundColor: "#FFF8E7", 
    padding: 12 
  },
  
  containerAlt: {
    flex: 1, 
    backgroundColor: "#FFFBEA", 
    padding: 12 
  },

  containerSale: {
    flex: 1, 
    backgroundColor: "#FFFDF6", 
    paddingHorizontal: 16 
  },

  // Header styles
  header: { 
    flexDirection: "row", 
    alignItems: "center", 
    justifyContent: "space-between", 
    marginBottom: 16 
  },
  headerTitle: { 
    fontSize: 22, 
    fontWeight: "700", 
    color: "#5A4636" 
  },

  // Search and filter styles
  searchContainer: { 
    flexDirection: "row", 
    alignItems: "center", 
    backgroundColor: "#fff", 
    borderRadius: 12, 
    paddingHorizontal: 10, 
    paddingVertical: 5, 
    marginBottom: 14, 
    elevation: 4 
  },
  searchInput: { 
    flex: 1, 
    fontSize: 12, 
    color: "#5C4F3B" 
  },
  filterButton: { 
    backgroundColor: "#D4AF37", 
    padding: 5, 
    borderRadius: 10, 
    marginLeft: 6 
  },

  // Section titles
  sectionTitle: { 
    fontSize: 14, 
    fontWeight: "700", 
    color: "#8C7853", 
    marginBottom: 8, 
    marginLeft: 4 
  },

  sectionTitleLarge: {
    fontSize: 20, 
    fontWeight: "700", 
    color: "#5C4B32", 
    marginBottom: 12 
  },

  // Categories
  categories: { 
    flexDirection: "row", 
    justifyContent: "space-around", 
    marginBottom: 18 
  },
  categoryItem: { 
    alignItems: "center" 
  },
  categoryImage: { 
    width: 60, 
    height: 60, 
    borderRadius: 30, 
    borderWidth: 2, 
    borderColor: "#D4AF37", 
    backgroundColor: "#fff" 
  },
  categoryText: { 
    marginTop: 4, 
    fontWeight: "600", 
    color: "#6D5B35", 
    fontSize: 10 
  },

  // Top categories
  topCategoriesContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 60,
    marginBottom: 20,
  },
  topCategory: {
    flex: 1,
    marginHorizontal: 5,
    backgroundColor: "#F9E6B3",
    borderRadius: 12,
    paddingVertical: 20,
    alignItems: "center",
    justifyContent: "center",
    elevation: 4,
  },
  topCategoryText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#5A4636",
  },

  // Subcategories
  subCategories: { 
    flexDirection: "row", 
    justifyContent: "space-between", 
    marginBottom: 20 
  },
  categoryCard: {
    flex: 1,
    marginHorizontal: 5,
    backgroundColor: "#F9E6B3",
    borderRadius: 12,
    paddingVertical: 20,
    alignItems: "center",
    justifyContent: "center",
    elevation: 4,
  },
  categoryCardText: { 
    fontWeight: "700", 
    color: "#5A4636", 
    fontSize: 16 
  },

  // Banner styles
  banner: { 
    backgroundColor: "#F9E6B3", 
    borderRadius: 18, 
    padding: 12, 
    alignItems: "center", 
    marginBottom: 18, 
    elevation: 5 
  },
  bannerLarge: {
    backgroundColor: "#F9E6B3",
    borderRadius: 25,
    paddingVertical: 30,
    paddingHorizontal: 20,
    alignItems: "center",
    marginBottom: 20,
    elevation: 5,
  },
  bannerText: { 
    fontSize: 16, 
    fontWeight: "800", 
    color: "#C5A100", 
    marginBottom: 6 
  },
  bannerTitle: {
    fontSize: 24,
    fontWeight: "800",
    color: "#5C4B32",
  },
  bannerSubText: { 
    fontSize: 13, 
    color: "#6D5B35" 
  },
  bannerSubtitle: {
    fontSize: 14,
    color: "#7A613D",
    marginTop: 5,
    textAlign: "center",
  },
  bannerPeople: { 
    flexDirection: "row", 
    gap: 8 
  },
  person: { 
    width: 40, 
    height: 40, 
    borderRadius: 20 
  },

  // Product styles
  products: { 
    flexDirection: "row", 
    flexWrap: "wrap", 
    justifyContent: "space-between" 
  },
  productCard: { 
    width: "48%", 
    backgroundColor: "#fff", 
    borderRadius: 12, 
    marginBottom: 10, 
    elevation: 3, 
    alignItems: "center", 
    padding: 6 
  },
  productCardSale: {
    width: cardWidth,
    backgroundColor: "#fff",
    borderRadius: 18,
    marginBottom: 18,
    elevation: 3,
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    alignItems: "center",
    paddingBottom: 10,
    overflow: "hidden",
  },
  imageWrapper: { 
    width: "100%", 
    height: 100, 
    position: "relative" 
  },
  imageContainer: {
    width: "100%",
    height: 160,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FFF8EF",
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  productImage: { 
    width: "100%", 
    height: "100%" 
  },
  heartIcon: { 
    position: "absolute", 
    top: 4, 
    right: 4,
    zIndex: 5 
  },
  productName: { 
    marginTop: 4, 
    fontSize: 10, 
    fontWeight: "600", 
    color: "#6D5B35" 
  },
  productNameSale: {
    marginTop: 6,
    fontSize: 13,
    fontWeight: "600",
    color: "#5A4636",
    textAlign: "center",
  },
  price: { 
    marginTop: 2, 
    fontSize: 12, 
    fontWeight: "bold", 
    color: "#8C7853" 
  },
  infoRow: { 
    flexDirection: "row", 
    justifyContent: "space-between", 
    width: "100%", 
    marginTop: 2, 
    alignItems: "center" 
  },
  soldText: { 
    fontSize: 8, 
    color: "#555" 
  },
  reviewWrapper: { 
    flexDirection: "row", 
    alignItems: "center", 
    gap: 1 
  },
  ratingRow: { 
    flexDirection: "row", 
    marginTop: 2, 
    gap: 2 
  },
  cartButton: { 
    marginTop: 4, 
    backgroundColor: "#D4AF37", 
    paddingVertical: 3, 
    paddingHorizontal: 8, 
    borderRadius: 8 
  },
  cartText: { 
    color: "#fff", 
    fontWeight: "600", 
    fontSize: 10 
  },

  // Discount badge
  discountBadge: {
    position: "absolute",
    top: 8,
    right: 8,
    backgroundColor: "#EBD8A4",
    paddingVertical: 3,
    paddingHorizontal: 6,
    borderRadius: 8,
    zIndex: 5,
  },
  discountText: { 
    color: "#6C5527", 
    fontWeight: "700", 
    fontSize: 10 
  },

  // Navigation
  backButton: {
    position: "absolute",
    top: 12,
    left: 12,
    zIndex: 10,
  },
  backArrow: {
    marginTop: 45,
    marginBottom: 10,
    marginLeft: 4,
  },

  // Footer Styles
  footer: {
    position: "absolute",
    bottom: 10,
    left: 10,
    right: 10,
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    paddingVertical: 8,
    backgroundColor: "#fff",
    borderRadius: 30,
    elevation: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  footerIcon: {
    width: 50,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
  },
  footerAddButton: {
    justifyContent: "center",
    alignItems: "center",
    bottom: 15,
  },

  // Product Detail Styles
  safeArea: { 
    flex: 1, 
    backgroundColor: "#FFF8E7" 
  },
  productDetailHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#FFF8E7",
    elevation: 3,
  },
  scrollContent: {
    paddingBottom: 120,
  },
  productDetailImage: {
    width: "100%",
    height: 350,
    borderRadius: 10,
    marginTop: 10,
  },
  infoContainer: {
    padding: 16,
    backgroundColor: "#fff",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    marginTop: -20,
  },
  productDetailName: { 
    fontSize: 20, 
    fontWeight: "700", 
    color: "#6D5B35" 
  },
  productDetailPrice: {
    fontSize: 18,
    color: "#D4AF37",
    fontWeight: "bold",
    marginVertical: 8,
  },
  description: {
    fontSize: 14,
    color: "#555",
    marginBottom: 14,
    lineHeight: 22,
    textAlign: "justify",
  },
  quantityContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
  },
  qtyButton: {
    backgroundColor: "#D4AF37",
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  qtySymbol: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
    textAlign: "center",
  },
  qtyText: {
    marginHorizontal: 16,
    fontSize: 16,
    fontWeight: "600",
    color: "#5C4F3B",
  },
  bottomButtonContainer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#fff",
    padding: 12,
    borderTopWidth: 1,
    borderColor: "#E5E5E5",
  },
  addToCartButton: {
    flexDirection: "row",
    backgroundColor: "#D4AF37",
    paddingVertical: 14,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  addToCartText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 15,
    marginLeft: 8,
  },

  // Splash Screen Styles
  splashContainer: { 
    flex: 1, 
    backgroundColor: "#FFF8E7", 
    alignItems: "center", 
    justifyContent: "center" 
  },
  logo: { 
    width: 150, 
    height: 150, 
    marginBottom: 20 
  },
  appName: { 
    fontSize: 38, 
    fontWeight: "700", 
    color: "#D4AF37", 
    letterSpacing: 2 
  },
  tagline: { 
    fontSize: 16, 
    marginTop: 8, 
    color: "#8C7853", 
    fontStyle: "italic" 
  },
});