// src/screens/Winter/WinterPretScreen.js
import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function WinterPretScreen({ navigation }) {
  const products = [
    { id: "1", name: "Cozy Jacket", image: require("../../../assets/wproduct1.png"), price: "$60", sold: 120, reviews: 4.5 },
    { id: "2", name: "Warm Sweater", image: require("../../../assets/wproduct2.png"), price: "$75", sold: 90, reviews: 4 },
    { id: "3", name: "Woolen Coat", image: require("../../../assets/wproduct3.png"), price: "$50", sold: 150, reviews: 5 },
    { id: "4", name: "Furry Hoodie", image: require("../../../assets/wproduct4.png"), price: "$85", sold: 80, reviews: 4.2 },
    { id: "5", name: "Winter Scarf", image: require("../../../assets/wproduct5.png"), price: "$95", sold: 70, reviews: 4.8 },
    { id: "6", name: "Long Winter Coat", image: require("../../../assets/wproduct3.png"), price: "$120", sold: 50, reviews: 4.9 },
    { id: "7", name: "Wool Sweater Dress", image: require("../../../assets/wproduct5.png"), price: "$80", sold: 65, reviews: 4.3 },
  ];

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={26} color="#333" />
        </TouchableOpacity>
        <Text style={styles.title}>Winter Pret Collection</Text>
        <View style={{ width: 26 }} />
      </View>

      {/* Banner */}
      <View style={styles.banner}>
        <Text style={styles.bannerText}>❄️ Winter Pret Collection</Text>
        <Text style={styles.bannerSubText}>Stay Warm & Stylish this Season</Text>
      </View>

      {/* Products Grid */}
      <View style={styles.products}>
        {products.map((item) => (
          <View key={item.id} style={styles.productCard}>
            <Image source={item.image} style={styles.productImage} resizeMode="cover" />
            <Text style={styles.productName} numberOfLines={1}>{item.name}</Text>
            <Text style={styles.price}>{item.price}</Text>
            <View style={styles.infoRow}>
              <Text style={styles.soldText}>{item.sold} Sold</Text>
              <View style={styles.reviewWrapper}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Ionicons
                    key={i}
                    name={i < Math.floor(item.reviews) ? "star" : "star-outline"}
                    size={12}
                    color="#FFD700"
                  />
                ))}
                {item.reviews % 1 !== 0 && <Ionicons name="star-half" size={12} color="#FFD700" />}
              </View>
            </View>
            <TouchableOpacity style={styles.cartButton}>
              <Text style={styles.cartText}>Add to Cart</Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FDFBF6", padding: 16 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 16 },
  title: { fontSize: 22, fontWeight: "700", color: "#5A4636" },

  banner: {
    backgroundColor: "#FFECD1",
    borderRadius: 25,
    padding: 20,
    alignItems: "center",
    marginBottom: 20,
    elevation: 5,
  },
  bannerText: { fontSize: 20, fontWeight: "800", color: "#8C5E3C" },
  bannerSubText: { fontSize: 14, color: "#6D5B35", marginTop: 4 },

  products: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  productCard: {
    width: "48%",
    backgroundColor: "#fff",
    borderRadius: 18,
    marginBottom: 18,
    elevation: 5,
    alignItems: "center",
    padding: 10,
  },
  productImage: { width: "100%", height: 160, borderRadius: 12 },
  productName: { marginTop: 6, fontSize: 14, fontWeight: "700", color: "#5A4636" },
  price: { marginTop: 2, fontSize: 14, fontWeight: "bold", color: "#8C7853" },
  infoRow: { flexDirection: "row", justifyContent: "space-between", width: "100%", marginTop: 4, alignItems: "center" },
  soldText: { fontSize: 10, color: "#555" },
  reviewWrapper: { flexDirection: "row", alignItems: "center", gap: 2 },
  cartButton: {
    marginTop: 8,
    backgroundColor: "#C5A880",
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 12,
  },
  cartText: { color: "#fff", fontWeight: "700", fontSize: 12 },
});
