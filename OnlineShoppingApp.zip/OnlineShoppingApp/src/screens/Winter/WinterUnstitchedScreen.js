import React from "react";
import { View, Text, TouchableOpacity, Image, ScrollView } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ using global styles

export default function WinterUnstitchedScreen({ navigation }) {
  const products = [
    {
      id: "1",
      name: "Winter Dress",
      image: require("../../../assets/wproduct1.png"),
      price: "RS 3000",
      sold: 100,
      reviews: 4.2,
      description: "High-quality wool fabric perfect for winter outfits.",
    },
    {
      id: "2",
      name: "Winter Dress",
      image: require("../../../assets/wproduct2.png"),
      price: "RS 3000",
      sold: 75,
      reviews: 4.5,
      description: "Soft and smooth silk with warm texture for premium designs.",
    },
    {
      id: "3",
      name: "Winter Dress",
      image: require("../../../assets/wproduct3.png"),
      price: "RS 3000",
      sold: 90,
      reviews: 4.8,
      description: "Durable wool blend material ideal for custom stitching.",
    },
    {
      id: "4",
      name: "Winter Dress",
      image: require("../../../assets/wproduct4.png"),
      price: "RS 3000",
      sold: 60,
      reviews: 5,
      description: "Luxurious cashmere for elegant, warm winter wear.",
    },
    {
      id: "5",
      name: "Winter Dress",
      image: require("../../../assets/wproduct5.png"),
      price: "RS 3000",
      sold: 110,
      reviews: 4.1,
      description: "Light and cozy knitted fabric suitable for casual outfits.",
    },
  ];

  return (
    <ScrollView style={GlobalStyles.container}>
      {/* Header */}
      <View style={GlobalStyles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={26} color="#5A4636" />
        </TouchableOpacity>
        <Text style={GlobalStyles.headerTitle}>Winter Unstitched</Text>
        <TouchableOpacity onPress={() => navigation.navigate("Cart")}>
          <Ionicons name="cart-outline" size={26} color="#5A4636" />
        </TouchableOpacity>
      </View>

      {/* Banner */}
      <View style={GlobalStyles.banner}>
        <Text style={GlobalStyles.bannerText}>🧵 Winter Unstitched Collection</Text>
        <Text style={GlobalStyles.bannerSubText}>
          Perfect Fabrics for Your Custom Designs
        </Text>
      </View>

      {/* Section Title */}
      <Text style={GlobalStyles.sectionTitle}>Unstitched Favorites</Text>

      {/* Product Grid */}
      <View style={GlobalStyles.products}>
        {products.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={GlobalStyles.productCard}
            onPress={() =>
              navigation.navigate("ProductDetail", { product: item })
            }
          >
            <View style={GlobalStyles.imageWrapper}>
              <Image
                source={item.image}
                style={GlobalStyles.productImage}
                resizeMode="contain"
              />
              <TouchableOpacity style={GlobalStyles.heartIcon}>
                <Ionicons name="heart-outline" size={16} color="#5A4636" />
              </TouchableOpacity>
            </View>

            <Text style={GlobalStyles.productName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={GlobalStyles.price}>{item.price}</Text>

            <View style={GlobalStyles.infoRow}>
              <Text style={GlobalStyles.soldText}>{item.sold} Sold</Text>
              <View style={GlobalStyles.reviewWrapper}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Ionicons
                    key={i}
                    name={
                      i < Math.floor(item.reviews)
                        ? "star"
                        : "star-outline"
                    }
                    size={10}
                    color="#D4AF37"
                  />
                ))}
                {item.reviews % 1 !== 0 && (
                  <Ionicons name="star-half" size={10} color="#D4AF37" />
                )}
              </View>
            </View>

            <TouchableOpacity style={GlobalStyles.cartButton}>
              <Text style={GlobalStyles.cartText}>Add</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}
