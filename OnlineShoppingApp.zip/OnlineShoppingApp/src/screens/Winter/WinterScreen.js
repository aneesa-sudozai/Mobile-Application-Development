import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ use centralized global styles

export default function WinterScreen({ navigation }) {
  const subCategories = [
    { id: 1, name: "Winter Pret" },
    { id: 2, name: "Winter Unstitched" },
  ];

  const products = [
    { id: "1", name: "Cozy Jacket", image: require("../../../assets/wproduct1.png"), price: "RS 3000", sold: 120, reviews: 4.5 },
    { id: "2", name: "Warm Sweater", image: require("../../../assets/wproduct2.png"), price: "RS 3000", sold: 90, reviews: 4 },
    { id: "3", name: "Woolen Coat", image: require("../../../assets/wproduct3.png"), price: "RS 3000", sold: 150, reviews: 5 },
    { id: "4", name: "Furry Hoodie", image: require("../../../assets/wproduct4.png"), price: "RS 3000", sold: 80, reviews: 4.2 },
    { id: "5", name: "Winter Scarf", image: require("../../../assets/wproduct5.png"), price: "RS 3000", sold: 70, reviews: 4.8 },
  ];

  return (
    <ScrollView style={GlobalStyles.container}>
      {/* Header */}
      <View style={GlobalStyles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={26} color="#5A4636" />
        </TouchableOpacity>
        <Text style={GlobalStyles.headerTitle}>Winter Collection</Text>
        <TouchableOpacity onPress={() => navigation.navigate("Cart")}>
          <Ionicons name="cart-outline" size={26} color="#5A4636" />
        </TouchableOpacity>
      </View>

      {/* Subcategories */}
      <View style={GlobalStyles.subCategories}>
        {subCategories.map((cat) => (
          <TouchableOpacity
            key={cat.id}
            style={GlobalStyles.categoryCard}
            onPress={() => {
              if (cat.name === "Winter Pret") navigation.navigate("WinterPret");
              else if (cat.name === "Winter Unstitched") navigation.navigate("WinterUnstitched");
            }}
          >
            <Text style={GlobalStyles.categoryCardText}>{cat.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Banner */}
      <View style={GlobalStyles.banner}>
        <Text style={GlobalStyles.bannerText}>❄️ Cozy Winter Sale!</Text>
        <Text style={GlobalStyles.bannerSubText}>Up to 50% Off on All Winter Wear</Text>
      </View>

      {/* Section Title */}
      <Text style={GlobalStyles.sectionTitle}>Winter Specials</Text>

      {/* Product Grid */}
      <View style={GlobalStyles.products}>
        {products.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={GlobalStyles.productCard}
            onPress={() => navigation.navigate("ProductDetail", { product: item })}
          >
            <View style={GlobalStyles.imageWrapper}>
              <Image
                source={item.image}
                style={GlobalStyles.productImage}
                resizeMode="contain"
              />
              <TouchableOpacity style={GlobalStyles.heartIcon}>
                <Ionicons name="heart-outline" size={16} color="#5A4636" />
              </TouchableOpacity>
            </View>

            <Text style={GlobalStyles.productName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={GlobalStyles.price}>{item.price}</Text>

            <View style={GlobalStyles.infoRow}>
              <Text style={GlobalStyles.soldText}>{item.sold} Sold</Text>
              <View style={GlobalStyles.reviewWrapper}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Ionicons
                    key={i}
                    name={i < Math.floor(item.reviews) ? "star" : "star-outline"}
                    size={10}
                    color="#D4AF37"
                  />
                ))}
                {item.reviews % 1 !== 0 && (
                  <Ionicons name="star-half" size={10} color="#D4AF37" />
                )}
              </View>
            </View>

            <TouchableOpacity style={GlobalStyles.cartButton}>
              <Text style={GlobalStyles.cartText}>Add</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}
