import React, { useState } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useRoute } from "@react-navigation/native";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ import your centralized styles

export default function ProductDetailScreen() {
  const navigation = useNavigation();
  const route = useRoute();
  const { product } = route.params;
  const [quantity, setQuantity] = useState(1);

  const increaseQty = () => setQuantity(quantity + 1);
  const decreaseQty = () => setQuantity(quantity > 1 ? quantity - 1 : 1);

  return (
    <SafeAreaView style={GlobalStyles.safeArea}>
      {/* 🔙 Header */}
      <View style={GlobalStyles.productDetailHeader}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={26} color="#5C4F3B" />
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate("Cart")}>
          <Ionicons name="cart-outline" size={26} color="#5C4F3B" />
        </TouchableOpacity>
      </View>

      {/* 🧴 Scrollable Product Details */}
      <ScrollView contentContainerStyle={GlobalStyles.scrollContent}>
        <Image
          source={product.image}
          style={GlobalStyles.productDetailImage}
          resizeMode="contain"
        />

        <View style={GlobalStyles.infoContainer}>
          <Text style={GlobalStyles.productDetailName}>{product.name}</Text>
          <Text style={GlobalStyles.productDetailPrice}>{product.price}</Text>

          {/* Short Description (only 3 lines) */}
          <Text
            numberOfLines={3}
            ellipsizeMode="tail"
            style={GlobalStyles.description}
          >
            {product.description ||
              `Experience the elegance of our premium ${product.name.toLowerCase()}. Crafted with precision, offering comfort, durability, and timeless appeal for every occasion.`}
          </Text>

          {/* 🔢 Quantity Selector */}
          <View style={GlobalStyles.quantityContainer}>
            <TouchableOpacity style={GlobalStyles.qtyButton} onPress={decreaseQty}>
              <Text style={GlobalStyles.qtySymbol}>–</Text>
            </TouchableOpacity>
            <Text style={GlobalStyles.qtyText}>{quantity}</Text>
            <TouchableOpacity style={GlobalStyles.qtyButton} onPress={increaseQty}>
              <Text style={GlobalStyles.qtySymbol}>+</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* 🛒 Add to Cart Button */}
      <View style={GlobalStyles.bottomButtonContainer}>
        <TouchableOpacity style={GlobalStyles.addToCartButton}>
          <Ionicons name="cart" size={18} color="#fff" />
          <Text style={GlobalStyles.addToCartText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
