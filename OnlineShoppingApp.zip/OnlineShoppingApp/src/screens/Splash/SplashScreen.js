import React, { useEffect, useRef } from "react";
import { View, Text, Image, Animated, StatusBar } from "react-native";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ import your global styles

export default function SplashScreen({ navigation }) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;

  useEffect(() => {
    // ✨ Fade + Scale animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 2000,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 3,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();

    // ⏳ Navigate to Home after 3 seconds
    const timer = setTimeout(() => {
      navigation.replace("Home");
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={GlobalStyles.splashContainer}>
      <StatusBar backgroundColor="#FFF8E7" barStyle="dark-content" />

      {/* 🖼 Logo Animation */}
      <Animated.Image
        source={require("../../../assets/logopic.png")}
        style={[
          GlobalStyles.logo,
          { opacity: fadeAnim, transform: [{ scale: scaleAnim }] },
        ]}
        resizeMode="contain"
      />

      {/* 🪶 App Name */}
      <Animated.Text
        style={[GlobalStyles.appName, { opacity: fadeAnim }]}
      >
        Hayaa
      </Animated.Text>

      {/* 💬 Tagline */}
      <Animated.Text
        style={[GlobalStyles.tagline, { opacity: fadeAnim }]}
      >
        Where Modesty Meets Luxury
      </Animated.Text>
    </View>
  );
}
