import React from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ adjust path if needed

export default function MenPerfumesScreen() {
  const navigation = useNavigation();

  const menPerfumes = [
    {
      id: "1",
      name: "Aventus",
      image: require("../../../assets/home_perfume.jpg"),
      price: "RS 5000",
      rating: 4.5,
      description:
        "Strong masculine fragrance with smoky pineapple and oakmoss notes.",
    },
    {
      id: "2",
      name: "Bleu de Chanel",
      image: require("../../../assets/home_perfume.jpg"),
      price: "RS 5000",
      rating: 4.2,
      description:
        "Modern and fresh scent with citrus and woody undertones.",
    },
    {
      id: "3",
      name: "Dior Homme",
      image: require("../../../assets/home_perfume.jpg"),
      price: "RS 5000",
      rating: 4.8,
      description:
        "Elegant and timeless with iris, vetiver, and leather tones.",
    },
    {
      id: "4",
      name: "Tom Ford Noir",
      image: require("../../../assets/home_perfume.jpg"),
      price: "RS 5000",
      rating: 4.6,
      description:
        "Dark, spicy, and mysterious fragrance for special evenings.",
    },
  ];

  return (
    <ScrollView
      style={GlobalStyles.containerAlt}
      showsVerticalScrollIndicator={false}
    >
      {/* 🔙 Back Button */}
      <TouchableOpacity
        style={GlobalStyles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Ionicons name="arrow-back" size={26} color="#5A4636" />
      </TouchableOpacity>

      {/* 🪶 Banner */}
      <View style={GlobalStyles.bannerLarge}>
        <MaterialCommunityIcons
          name="bottle-wine-outline"
          size={40}
          color="#6D5B35"
        />
        <Text style={GlobalStyles.bannerTitle}>
          🔥 Men’s Perfume Collection 🔥
        </Text>
        <Text style={GlobalStyles.bannerSubtitle}>
          Bold. Classic. Timeless Fragrances for Every Gentleman.
        </Text>
      </View>

      {/* 🏷️ Section Title */}
      <Text style={GlobalStyles.sectionTitleLarge}>Top Men's Picks</Text>

      {/* 🧴 Perfume Cards */}
      <View style={GlobalStyles.products}>
        {menPerfumes.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={GlobalStyles.productCardSale}
            activeOpacity={0.9}
            onPress={() =>
              navigation.navigate("ProductDetail", { product: item })
            }
          >
            {/* ❤️ Favorite Icon */}
            <TouchableOpacity style={GlobalStyles.heartIcon}>
              <Ionicons name="heart-outline" size={20} color="#4E3B31" />
            </TouchableOpacity>

            {/* 🖼️ Product Image */}
            <View style={GlobalStyles.imageContainer}>
              <Image
                source={item.image}
                style={GlobalStyles.productImage}
                resizeMode="contain"
              />
            </View>

            {/* ✨ Product Name */}
            <Text style={GlobalStyles.productNameSale} numberOfLines={1}>
              {item.name}
            </Text>

            {/* ⭐ Rating */}
            <View style={GlobalStyles.reviewWrapper}>
              {Array.from({ length: 5 }).map((_, i) => (
                <Ionicons
                  key={i}
                  name={i < Math.floor(item.rating) ? "star" : "star-outline"}
                  size={12}
                  color="#C6A76F"
                />
              ))}
              {item.rating % 1 !== 0 && (
                <Ionicons name="star-half" size={12} color="#C6A76F" />
              )}
            </View>

            {/* 💸 Price */}
            <Text style={GlobalStyles.price}>{item.price}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}
