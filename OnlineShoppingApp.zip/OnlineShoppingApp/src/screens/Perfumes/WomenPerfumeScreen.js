import React from "react";
import { View, Text, ScrollView, Image, TouchableOpacity, Dimensions } from "react-native";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ import your global styles

const { width } = Dimensions.get("window");
const cardWidth = (width - 36) / 2;

export default function WomenPerfumesScreen() {
  const navigation = useNavigation();

  const womenPerfumes = [
    { id: "1", name: "Chanel No.5", price: "RS 5000", rating: 4.8, image: require("../../../assets/home_perfume.jpg") },
    { id: "2", name: "Flowerbomb", price: "RS 5000", rating: 4.6, image: require("../../../assets/home_perfume.jpg") },
    { id: "3", name: "J'adore", price: "RS 5000", rating: 4.9, image: require("../../../assets/home_perfume.jpg") },
  ];

  return (
    <ScrollView style={GlobalStyles.containerAlt} showsVerticalScrollIndicator={false}>
      {/* 🔙 Back Button */}
      <TouchableOpacity style={GlobalStyles.backButton} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={26} color="#5A4636" />
      </TouchableOpacity>

      {/* 🌸 Banner Section */}
      <View style={GlobalStyles.bannerLarge}>
        <MaterialCommunityIcons name="bottle-wine-outline" size={40} color="#6D5B35" />
        <Text style={GlobalStyles.bannerText}>🌸 Women’s Perfume Collection 🌸</Text>
        <Text style={GlobalStyles.bannerSubtitle}>Elegant, Timeless Fragrances for Every Occasion.</Text>
      </View>

      {/* 🏷 Section Title */}
      <Text style={GlobalStyles.sectionTitle}>Top Women's Picks</Text>

      {/* 🧴 Perfume Cards */}
      <View style={GlobalStyles.products}>
        {womenPerfumes.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={[GlobalStyles.productCardSale, { width: cardWidth }]}
            activeOpacity={0.9}
            onPress={() => navigation.navigate("ProductDetail", { product: item })}
          >
            {/* ❤️ Favorite Icon */}
            <TouchableOpacity style={GlobalStyles.heartIcon}>
              <Ionicons name="heart-outline" size={20} color="#4E3B31" />
            </TouchableOpacity>

            {/* 🖼 Product Image */}
            <View style={GlobalStyles.imageContainer}>
              <Image source={item.image} style={GlobalStyles.productImage} resizeMode="contain" />
            </View>

            {/* 🧾 Product Name */}
            <Text style={GlobalStyles.productNameSale} numberOfLines={1}>
              {item.name}
            </Text>

            {/* ⭐ Rating */}
            <View style={GlobalStyles.ratingRow}>
              {Array.from({ length: 5 }).map((_, i) => (
                <Ionicons
                  key={i}
                  name={i < Math.floor(item.rating) ? "star" : "star-outline"}
                  size={12}
                  color="#C6A76F"
                />
              ))}
              {item.rating % 1 !== 0 && <Ionicons name="star-half" size={12} color="#C6A76F" />}
            </View>

            {/* 💰 Price */}
            <Text style={GlobalStyles.price}>{item.price}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}
