import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ make sure path is correct

export default function PerfumesScreen() {
  const navigation = useNavigation();

  const images = {
    rose: require("../../../assets/perfume1.png"),
    lavender: require("../../../assets/perfume2.png"),
    jasmine: require("../../../assets/perfume3.png"),
    vanilla: require("../../../assets/perfume4.png"),
    sandalwood: require("../../../assets/perfume5.png"),
    citrus: require("../../../assets/perfume6.png"),
    rosegold: require("../../../assets/perfume1.png"),
  };

  const topCategories = [
    { key: "Men", screen: "MenPerfumes" },
    { key: "Women", screen: "WomenPerfumes" },
  ];

  const topPerfumes = [
    {
      id: "1",
      name: "Rose",
      price: "RS 5000",
      rating: 4.5,
      image: images.rose,
      description: "A floral fragrance that embodies elegance and love.",
    },
    {
      id: "2",
      name: "Lavender",
      price: "RS 5000",
      rating: 4.0,
      image: images.lavender,
      description: "Fresh lavender aroma for a calm and soothing touch.",
    },
    {
      id: "3",
      name: "Jasmine",
      price: "RS 5000",
      rating: 4.2,
      image: images.jasmine,
      description: "Classic jasmine scent that lasts all day.",
    },
  ];

  const allPerfumes = [
    {
      id: "4",
      name: "Vanilla",
      price: "RS 5000",
      rating: 4.0,
      image: images.vanilla,
      description: "Sweet and warm vanilla fragrance for everyday use.",
    },
    {
      id: "5",
      name: "Sandalwood",
      price: "RS 5000",
      rating: 4.5,
      image: images.sandalwood,
      description: "Earthy and woody scent with rich undertones.",
    },
    {
      id: "6",
      name: "Citrus",
      price: "RS 5000",
      rating: 4.2,
      image: images.citrus,
      description: "Zesty, refreshing fragrance that energizes you.",
    },
    {
      id: "7",
      name: "Rose Gold",
      price: "RS 5000",
      rating: 4.8,
      image: images.rosegold,
      description: "Luxurious blend of rose and musk — timeless beauty.",
    },
  ];

  return (
    <ScrollView style={GlobalStyles.containerAlt} showsVerticalScrollIndicator={false}>
      {/* 🔙 Back Button */}
      <TouchableOpacity
        style={GlobalStyles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Ionicons name="arrow-back" size={26} color="#5A4636" />
      </TouchableOpacity>

      {/* 👔 Top Categories */}
      <View style={GlobalStyles.topCategoriesContainer}>
        {topCategories.map((item) => (
          <TouchableOpacity
            key={item.key}
            style={GlobalStyles.topCategory}
            onPress={() => navigation.navigate(item.screen)}
          >
            <Text style={GlobalStyles.topCategoryText}>{item.key}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* 🌿 Banner */}
      <View style={GlobalStyles.banner}>
        <Text style={GlobalStyles.bannerText}>🌿 Summer Vibes Sale!</Text>
        <Text style={GlobalStyles.bannerSubText}>
          Up to 40% Off on Fresh Arrivals
        </Text>
      </View>

      {/* 🌸 Top Perfumes */}
      <Text style={GlobalStyles.sectionTitle}>Top Perfumes</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ marginBottom: 12 }}
      >
        {topPerfumes.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={GlobalStyles.productCard}
            activeOpacity={0.9}
            onPress={() =>
              navigation.navigate("ProductDetail", { product: item })
            }
          >
            <View style={GlobalStyles.imageWrapper}>
              <Image
                source={item.image}
                style={GlobalStyles.productImage}
                resizeMode="contain"
              />
              <TouchableOpacity style={GlobalStyles.heartIcon}>
                <Ionicons name="heart-outline" size={20} color="#4E3B31" />
              </TouchableOpacity>
            </View>
            <Text style={GlobalStyles.productName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={GlobalStyles.price}>{item.price}</Text>
            <View style={GlobalStyles.reviewWrapper}>
              {Array.from({ length: 5 }).map((_, i) => (
                <Ionicons
                  key={i}
                  name={i < Math.floor(item.rating) ? "star" : "star-outline"}
                  size={12}
                  color="#C6A76F"
                />
              ))}
              {item.rating % 1 !== 0 && (
                <Ionicons name="star-half" size={12} color="#C6A76F" />
              )}
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* 🌼 All Perfumes */}
      <Text style={GlobalStyles.sectionTitle}>All Perfumes</Text>
      <View style={GlobalStyles.products}>
        {allPerfumes.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={GlobalStyles.productCard}
            activeOpacity={0.9}
            onPress={() =>
              navigation.navigate("ProductDetail", { product: item })
            }
          >
            <View style={GlobalStyles.imageWrapper}>
              <Image
                source={item.image}
                style={GlobalStyles.productImage}
                resizeMode="contain"
              />
              <TouchableOpacity style={GlobalStyles.heartIcon}>
                <Ionicons name="heart-outline" size={20} color="#4E3B31" />
              </TouchableOpacity>
            </View>
            <Text style={GlobalStyles.productName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={GlobalStyles.price}>{item.price}</Text>
            <View style={GlobalStyles.reviewWrapper}>
              {Array.from({ length: 5 }).map((_, i) => (
                <Ionicons
                  key={i}
                  name={i < Math.floor(item.rating) ? "star" : "star-outline"}
                  size={12}
                  color="#C6A76F"
                />
              ))}
              {item.rating % 1 !== 0 && (
                <Ionicons name="star-half" size={12} color="#C6A76F" />
              )}
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}
