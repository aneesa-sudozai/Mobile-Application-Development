// src/screens/Summer/SummerPretScreen.js
import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function SummerPretScreen({ navigation }) {
  const products = [
    {
      id: "1",
      name: "Floral Dress",
      image: require("../../../assets/product1.png"),
      price: "RS 4000",
      sold: 120,
      reviews: 4.2,
      description: "A breezy floral dress perfect for sunny summer days.",
    },
    {
      id: "2",
      name: "Casual Top",
      image: require("../../../assets/product2.png"),
      price: "RS 4000",
      sold: 90,
      reviews: 4.5,
      description: "A comfortable casual top with soft cotton fabric.",
    },
    {
      id: "3",
      name: "Summer Skirt",
      image: require("../../../assets/product3.png"),
      price: "RS 4000",
      sold: 80,
      reviews: 4.8,
      description: "Lightweight summer skirt with elegant floral patterns.",
    },
    {
      id: "4",
      name: "Beach Shorts",
      image: require("../../../assets/product4.png"),
      price: "RS 4000",
      sold: 60,
      reviews: 5,
      description: "Trendy shorts perfect for beach outings or casual wear.",
    },
    {
      id: "5",
      name: "Sundress",
      image: require("../../../assets/product5.png"),
      price: "RS 4000",
      sold: 70,
      reviews: 4.1,
      description: "Stylish sundress with a flattering fit and vibrant color.",
    },
  ];

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[styles.headerIcon, { left: 0 }]}
        >
          <Ionicons name="arrow-back" size={26} color="#5A4636" />
        </TouchableOpacity>

        <Text style={styles.title}>Summer Pret</Text>

        <TouchableOpacity
          onPress={() => navigation.navigate("Cart")}
          style={[styles.headerIcon, { right: 0 }]}
        >
          <Ionicons name="cart-outline" size={26} color="#5A4636" />
        </TouchableOpacity>
      </View>

      {/* Banner */}
      <View style={styles.banner}>
        <Text style={styles.bannerText}>☀️ Summer Pret Collection</Text>
        <Text style={styles.bannerSubText}>Ready-to-Wear Summer Styles</Text>
      </View>

      {/* Products */}
      <View style={styles.products}>
        {products.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={styles.productCard}
            onPress={() => navigation.navigate("ProductDetail", { product: item })}
          >
            <View style={styles.imageWrapper}>
              <Image source={item.image} style={styles.productImage} resizeMode="contain" />
              <TouchableOpacity style={styles.heartIcon}>
                <Ionicons name="heart-outline" size={20} color="#4E3B31" />
              </TouchableOpacity>
            </View>

            <Text style={styles.productName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={styles.price}>{item.price}</Text>

            <View style={styles.infoRow}>
              <Text style={styles.soldText}>{item.sold} Sold</Text>
              <View style={styles.reviewWrapper}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Ionicons
                    key={i}
                    name={i < Math.floor(item.reviews) ? "star" : "star-outline"}
                    size={12}
                    color="#C6A76F"
                  />
                ))}
                {item.reviews % 1 !== 0 && (
                  <Ionicons name="star-half" size={12} color="#C6A76F" />
                )}
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FAF7F0", padding: 12 },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
    position: "relative",
  },
  title: { fontSize: 22, fontWeight: "700", color: "#5A4636" },
  headerIcon: {
    position: "absolute",
    top: 0,
    bottom: 0,
    justifyContent: "center",
    paddingHorizontal: 8,
  },

  banner: {
    width: "100%",
    backgroundColor: "#F9E6B3",
    borderRadius: 12,
    paddingVertical: 20,
    paddingHorizontal: 12,
    alignItems: "center",
    marginBottom: 18,
    elevation: 5,
  },
  bannerText: { fontSize: 16, fontWeight: "800", color: "#C5A100", marginBottom: 4 },
  bannerSubText: { fontSize: 13, color: "#6D5B35" },

  products: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  productCard: {
    width: "48%",
    backgroundColor: "#fff",
    borderRadius: 12,
    marginBottom: 10,
    elevation: 3,
    alignItems: "center",
    padding: 6,
  },
  imageWrapper: { width: "100%", height: 100, position: "relative" },
  productImage: { width: "100%", height: "100%" },
  heartIcon: { position: "absolute", top: 4, right: 4 },
  productName: { marginTop: 4, fontSize: 10, fontWeight: "600", color: "#6D5B35" },
  price: { marginTop: 2, fontSize: 12, fontWeight: "bold", color: "#8C7853" },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: 2,
    alignItems: "center",
  },
  soldText: { fontSize: 8, color: "#555" },
  reviewWrapper: { flexDirection: "row", alignItems: "center", gap: 1 },
});
