import React, { useRef, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  Animated,
  ScrollView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ make sure path matches your structure

export default function HomeScreen() {
  const navigation = useNavigation();
  const slideAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(slideAnim, { toValue: 10, duration: 1500, useNativeDriver: true }),
        Animated.timing(slideAnim, { toValue: -10, duration: 1500, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  const categories = [
    { key: "Summer", image: require("../../../assets/home_summer.jpg") },
    { key: "Sale", image: require("../../../assets/home_sale.jpg") },
    { key: "Perfume", image: require("../../../assets/home_perfume.jpg") },
    { key: "Winter", image: require("../../../assets/home_winter.jpg") },
  ];

  const products = [
    { id: "1", name: "Perfume", image: require("../../../assets/product_perfume.png"), price: "RS 6000", sold: 120, reviews: 4 },
    { id: "2", name: "Men Shirt", image: require("../../../assets/product_men1.png"), price: "RS 6000", sold: 85, reviews: 5 },
    { id: "3", name: "Summer Dress", image: require("../../../assets/product_summer.png"), price: "RS 6000", sold: 150, reviews: 4.5 },
    { id: "4", name: "Winter Jacket", image: require("../../../assets/product_winter.png"), price: "RS 6000", sold: 95, reviews: 4.8 },
  ];

  return (
    <View style={GlobalStyles.container}>
      <ScrollView contentContainerStyle={GlobalStyles.scrollContent}>
        
        {/* 🔍 Search Bar */}
        <View style={GlobalStyles.searchContainer}>
          <TextInput placeholder="Search..." style={GlobalStyles.searchInput} />
          <TouchableOpacity style={GlobalStyles.filterButton}>
            <Ionicons name="filter" size={18} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* 🏷️ Categories */}
        <Text style={GlobalStyles.sectionTitle}>Categories</Text>
        <View style={GlobalStyles.categories}>
          {categories.map((item) => (
            <TouchableOpacity
              key={item.key}
              style={GlobalStyles.categoryItem}
              onPress={() => {
                if (item.key === "Perfume") {
                  navigation.navigate("Perfumes");
                } else {
                  navigation.navigate(item.key);
                }
              }}
            >
              <Image source={item.image} style={GlobalStyles.categoryImage} resizeMode="contain" />
              <Text style={GlobalStyles.categoryText}>{item.key}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* 🎉 Banner Section */}
        <Animated.View style={[GlobalStyles.banner, { transform: [{ translateX: slideAnim }] }]}>
          <Text style={GlobalStyles.bannerText}>🔥 Winter Sale 50% OFF!</Text>
          <View style={GlobalStyles.bannerPeople}>
            <Image source={require("../../../assets/person.jpg")} style={GlobalStyles.person} resizeMode="contain" />
            <Image source={require("../../../assets/person.jpg")} style={GlobalStyles.person} resizeMode="contain" />
          </View>
        </Animated.View>

        {/* 🛍️ Product Section */}
        <Text style={GlobalStyles.sectionTitle}>Our Top Products</Text>
        <View style={GlobalStyles.products}>
          {products.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={GlobalStyles.productCard}
              onPress={() => navigation.navigate("ProductDetail", { product: item })}
            >
              <View style={GlobalStyles.imageWrapper}>
                <Image source={item.image} style={GlobalStyles.productImage} resizeMode="contain" />
                <TouchableOpacity style={GlobalStyles.heartIcon}>
                  <Ionicons name="heart-outline" size={16} color="black" />
                </TouchableOpacity>
              </View>
              <Text style={GlobalStyles.productName} numberOfLines={1}>{item.name}</Text>
              <Text style={GlobalStyles.price}>{item.price}</Text>
              <View style={GlobalStyles.infoRow}>
                <Text style={GlobalStyles.soldText}>{item.sold} Sold</Text>
                <View style={GlobalStyles.reviewWrapper}>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Ionicons
                      key={i}
                      name={i < Math.floor(item.reviews) ? "star" : "star-outline"}
                      size={10}
                      color="#FFD700"
                    />
                  ))}
                  {item.reviews % 1 !== 0 && <Ionicons name="star-half" size={10} color="#FFD700" />}
                </View>
              </View>
              <TouchableOpacity style={GlobalStyles.cartButton}>
                <Text style={GlobalStyles.cartText}>Add</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* ⚙️ Footer Navigation */}
      <View style={GlobalStyles.footer}>
        <TouchableOpacity style={GlobalStyles.footerIcon}>
          <Ionicons name="home" size={24} color="#000" />
        </TouchableOpacity>

        <TouchableOpacity style={GlobalStyles.footerAddButton}>
          <Ionicons name="add-circle" size={60} color="#D4AF37" />
        </TouchableOpacity>

        <TouchableOpacity style={GlobalStyles.footerIcon}>
          <Ionicons name="notifications-outline" size={24} color="#000" />
        </TouchableOpacity>
      </View>
    </View>
  );
}
