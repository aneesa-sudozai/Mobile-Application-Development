import React from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { GlobalStyles } from "../../styles/GlobalStyles"; // ✅ use your global style file

export default function SaleScreen() {
  const navigation = useNavigation();

  const saleProducts = [
    {
      id: "1",
      name: "Stylish Dress",
      image: require("../../../assets/product1.png"),
      price: "RS 5000",
      rating: 4.5,
      description:
        "Stylish red dress perfect for special occasions. Sweet floral pink perfume, your daily confidence boost.",
    },
    {
      id: "2",
      name: "Stylish Outfit",
      image: require("../../../assets/product2.png"),
      price: "RS 5000",
      rating: 5,
      description:
        "Refreshing blue perfume with a long-lasting fragrance. Sweet floral pink perfume, your daily confidence boost.",
    },
    {
      id: "3",
      name: "Stylish Outfit",
      image: require("../../../assets/product3.png"),
      price: "RS 5000",
      rating: 4,
      description:
        "Elegant green dress for summer evenings. Sweet floral pink perfume, your daily confidence boost.",
    },
    {
      id: "4",
      name: "Stylish Outfit",
      image: require("../../../assets/product4.png"),
      price: "RS 5000",
      rating: 4.8,
      description:
        "Sweet floral pink perfume, your daily confidence boost. Sweet floral pink perfume, your daily confidence boost.",
    },
    {
      id: "5",
      name: "Stylish Outfit",
      image: require("../../../assets/product5.png"),
      price: "RS 5000",
      rating: 4.2,
      description:
        "Bright and breezy yellow dress for sunshine lovers. Sweet floral pink perfume, your daily confidence boost.",
    },
  ];

  return (
    <ScrollView style={GlobalStyles.containerSale} showsVerticalScrollIndicator={false}>
      {/* 🔙 Back Arrow */}
      <TouchableOpacity style={GlobalStyles.backArrow} onPress={() => navigation.goBack()}>
        <Ionicons name="arrow-back" size={28} color="#5C4B32" />
      </TouchableOpacity>

      {/* 🏷️ Sale Banner */}
      <View style={GlobalStyles.bannerLarge}>
        <Text style={GlobalStyles.bannerTitle}>Exclusive Sale</Text>
        <Text style={GlobalStyles.bannerSubtitle}>
          Enjoy elegant discounts on your favorites
        </Text>
      </View>

      {/* 🧾 Section Title */}
      <Text style={GlobalStyles.sectionTitleLarge}>On Sale Now</Text>

      {/* 🛍️ Product Grid */}
      <View style={GlobalStyles.products}>
        {saleProducts.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={GlobalStyles.productCardSale}
            activeOpacity={0.9}
            onPress={() => navigation.navigate("ProductDetail", { product: item })}
          >
            {/* 🔖 Discount Tag */}
            <View style={GlobalStyles.discountBadge}>
              <Text style={GlobalStyles.discountText}>25% OFF</Text>
            </View>

            {/* ❤️ Wishlist Icon */}
            <TouchableOpacity style={GlobalStyles.heartIcon}>
              <Ionicons name="heart-outline" size={18} color="#B8903E" />
            </TouchableOpacity>

            {/* 🖼️ Product Image */}
            <View style={GlobalStyles.imageContainer}>
              <Image
                source={item.image}
                style={GlobalStyles.productImage}
                resizeMode="contain"
              />
            </View>

            {/* 🏷️ Product Name */}
            <Text style={GlobalStyles.productNameSale} numberOfLines={1}>
              {item.name}
            </Text>

            {/* ⭐ Rating */}
            <View style={GlobalStyles.ratingRow}>
              {Array.from({ length: 5 }).map((_, i) => (
                <Ionicons
                  key={i}
                  name={i < Math.floor(item.rating) ? "star" : "star-outline"}
                  size={12}
                  color="#D4AF37"
                />
              ))}
            </View>

            {/* 💰 Price */}
            <Text style={GlobalStyles.price}>{item.price}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}
