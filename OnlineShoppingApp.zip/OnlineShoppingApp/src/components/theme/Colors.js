export default {
  primary: "#C5A572", // Soft Gold
  background: "#F8F5F0", // Cream / Ivory
  textDark: "#3E3E3E",
  beige: "#E9DCC9", // Warm Beige
};
