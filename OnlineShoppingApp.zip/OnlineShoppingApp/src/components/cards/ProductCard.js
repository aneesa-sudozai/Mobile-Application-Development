import React, { useState } from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity } from "react-native";
import Colors from "../../theme/Colors";

const ProductCard = ({ name, price, image, small }) => {
  const [pressed, setPressed] = useState(false);

  return (
    <TouchableOpacity
      style={[styles.card, small ? styles.small : styles.large]}
      activeOpacity={0.8}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
    >
      <Image source={image} style={styles.image} />
      <View style={styles.info}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.price}>{price}</Text>
        <TouchableOpacity
          style={[styles.cartButton, pressed && { backgroundColor: "#a88656" }]}
        >
          <Text style={styles.cartText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    width: "47%",
    backgroundColor: "#fff",
    borderRadius: 15,
    marginBottom: 15,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },
  small: {
    height: 220,
  },
  large: {
    height: 260,
  },
  image: {
    width: "100%",
    height: "65%",
  },
  info: {
    padding: 8,
  },
  name: {
    fontWeight: "bold",
    color: Colors.textDark,
  },
  price: {
    color: Colors.primary,
    marginBottom: 5,
  },
  cartButton: {
    backgroundColor: Colors.primary,
    borderRadius: 8,
    paddingVertical: 5,
  },
  cartText: {
    textAlign: "center",
    color: "#fff",
    fontWeight: "600",
  },
});

export default ProductCard;
