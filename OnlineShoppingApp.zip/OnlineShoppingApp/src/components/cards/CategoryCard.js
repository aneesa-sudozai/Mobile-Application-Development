import React from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity } from "react-native";
import Colors from "../../theme/Colors";

const CategoryCard = ({ title, image }) => (
  <TouchableOpacity style={styles.card}>
    <Image source={image} style={styles.image} />
    <Text style={styles.title}>{title}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  card: {
    width: "47%",
    marginBottom: 15,
    backgroundColor: Colors.beige,
    borderRadius: 15,
    overflow: "hidden",
  },
  image: {
    width: "100%",
    height: 100,
  },
  title: {
    textAlign: "center",
    padding: 8,
    fontWeight: "bold",
    color: Colors.textDark,
  },
});

export default CategoryCard;
