// Stack Navigator 
import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../../screens/Home/HomeScreen';
import WinterScreen from '../../screens/Winter/WinterScreen';
import SummerScreen from '../../screens/Summer/SummerScreen';
import PerfumesScreen from '../../screens/Perfumes/PerfumesScreen';
import SaleScreen from '../../screens/Sale/SaleScreen';
import ProductDetailScreen from '../../screens/ProductDetail/ProductDetailScreen';

// Winter Subcategories
import WinterPretScreen from '../../screens/Winter/WinterPretScreen';
import WinterUnstitchedScreen from '../../screens/Winter/WinterUnstitchedScreen';

// Summer Subcategories
import SummerPretScreen from '../../screens/Summer/SummerPretScreen';
import SummerUnstitchedScreen from '../../screens/Summer/SummerUnstitchedScreen';

// Perfume Subcategories
import MenPerfumeScreen from '../../screens/Perfumes/MenPerfumeScreen';
import WomenPerfumeScreen from '../../screens/Perfumes/WomenPerfumeScreen';

const Stack = createStackNavigator();

const StackNavigator = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Winter" component={WinterScreen} />
      <Stack.Screen name="Summer" component={SummerScreen} />
      <Stack.Screen name="Perfumes" component={PerfumesScreen} />
      <Stack.Screen name="Sale" component={SaleScreen} />
      <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
      
      {/* Winter Subcategories */}
      <Stack.Screen name="WinterPret" component={WinterPretScreen} />
      <Stack.Screen name="WinterUnstitched" component={WinterUnstitchedScreen} />
      
      {/* Summer Subcategories */}
      <Stack.Screen name="SummerPret" component={SummerPretScreen} />
      <Stack.Screen name="SummerUnstitched" component={SummerUnstitchedScreen} />
      
      {/* Perfume Subcategories */}
      <Stack.Screen name="MenPerfume" component={MenPerfumeScreen} />
      <Stack.Screen name="WomenPerfume" component={WomenPerfumeScreen} />
    </Stack.Navigator>
  );
};

export default StackNavigator;