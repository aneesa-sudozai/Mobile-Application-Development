// src/navigation/root/AppNavigator.js
import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

// Screens
import SplashScreen from "../../screens/Splash/SplashScreen";
import HomeScreen from "../../screens/Home/HomeScreen";
import WinterScreen from "../../screens/Winter/WinterScreen";
import WinterPretScreen from "../../screens/Winter/WinterPretScreen";
import WinterUnstitchedScreen from "../../screens/Winter/WinterUnstitchedScreen";
import SummerScreen from "../../screens/Summer/SummerScreen";
import SummerPretScreen from "../../screens/Summer/SummerPretScreen";
import SummerUnstitchedScreen from "../../screens/Summer/SummerUnstitchedScreen";
import SaleScreen from "../../screens/Sale/SaleScreen";
import PerfumesScreen from "../../screens/Perfumes/PerfumesScreen";
import MenPerfumesScreen from "../../screens/Perfumes/MenPerfumeScreen";
import WomenPerfumesScreen from "../../screens/Perfumes/WomenPerfumeScreen";
import ProductDetailScreen from "../../screens/ProductDetail/ProductDetailScreen"; 

const Stack = createStackNavigator();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }} initialRouteName="Splash">
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Winter" component={WinterScreen} />
        <Stack.Screen name="WinterPret" component={WinterPretScreen} />
        <Stack.Screen name="WinterUnstitched" component={WinterUnstitchedScreen} />
        <Stack.Screen name="Summer" component={SummerScreen} />
        <Stack.Screen name="SummerPret" component={SummerPretScreen} />
        <Stack.Screen name="SummerUnstitched" component={SummerUnstitchedScreen} />
        <Stack.Screen name="Sale" component={SaleScreen} />
        <Stack.Screen name="Perfumes" component={PerfumesScreen} />
        <Stack.Screen name="MenPerfumes" component={MenPerfumesScreen} />
        <Stack.Screen name="WomenPerfumes" component={WomenPerfumesScreen} />
        <Stack.Screen name="ProductDetail" component={ProductDetailScreen} /> 
      </Stack.Navigator>
    </NavigationContainer>
  );
}
